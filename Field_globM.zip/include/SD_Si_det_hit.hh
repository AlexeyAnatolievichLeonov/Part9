#ifndef SD_Si_det_hit_h
#define SD_Si_det_hit_h 1

#include "G4VHit.hh"
#include "G4THitsCollection.hh"
#include "G4Allocator.hh"
#include "G4ThreeVector.hh"

class SD_Si_det_hit : public G4VHit
{
 public:
  SD_Si_det_hit();
  ~SD_Si_det_hit();
  SD_Si_det_hit(const SD_Si_det_hit&);
  const SD_Si_det_hit& operator=(const SD_Si_det_hit&);
  G4int operator==(const SD_Si_det_hit&) const;
  
  inline void* operator new(size_t);
  inline void  operator delete(void *aHit);

  void Draw();  
  void Print();
  
  void SetEdep(const double e) {this->eDep_hit=e;}
  G4double GetEdep() const {return eDep_hit;}

  void SetLayerNumber(const int c) {this->layerNumber_hit=c;}  
  G4int GetLayerNumber() const {return layerNumber_hit;}
  
 private:
  G4int layerNumber_hit;
  G4double eDep_hit;
};

typedef G4THitsCollection<SD_Si_det_hit> SD_Si_det_hitCollection;

extern G4Allocator<SD_Si_det_hit> hitAllocatorSD;

inline void* SD_Si_det_hit::operator new(size_t)
{
 void* aHit;
 aHit = (void*) hitAllocatorSD.MallocSingle();
 return aHit;
}

inline void SD_Si_det_hit::operator delete(void* aHit)
{
 hitAllocatorSD.FreeSingle((SD_Si_det_hit*) aHit);
}

#endif
