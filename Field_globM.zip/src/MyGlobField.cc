#include "MyGlobField.hh"

//#define SU *mm

MyGlobField::MyGlobField()
{
// Total field
 globFieldManager = G4TransportationManager::GetTransportationManager()->GetFieldManager();
 globMfield       = new G4UniformMagField(G4ThreeVector(1.*tesla,0.,0.));
 globFieldManager->SetDetectorField(globMfield);
 globFieldManager->CreateChordFinder(globMfield);
}

MyGlobField::~MyGlobField()
{
 delete globMfield;
 globMfield = nullptr;
}

