#include "MyLocField.hh"

//#define SU *mm

MyLocField::MyLocField()

{
// Local field
 myEMfield      = new G4UniformMagField(G4ThreeVector(100.*tesla,0.,0.));
 myFieldManager = new G4FieldManager(myEMfield);
}

MyLocField::~MyLocField()
{
 delete myEMfield;
 myEMfield = nullptr;
}

