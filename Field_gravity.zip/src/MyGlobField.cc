#include "MyGlobField.hh"

//#define SU *mm

MyGlobField::MyGlobField()
{
 using StepperType = G4ClassicalRK4;
// Total field
 globFieldManager = G4TransportationManager::GetTransportationManager()->GetFieldManager();
 globGravfield    = new G4UniformGravityField();
 G4RepleteEofM* equation = new G4RepleteEofM(globGravfield);
 globFieldManager->SetDetectorField(globGravfield);
 
 StepperType* stepper = new StepperType(equation,8);

 G4double minStep           = 0.01*mm;
 G4ChordFinder* chordFinder = nullptr;     
 
 auto intgrDriver = new G4IntegrationDriver<StepperType>(minStep, stepper, stepper->GetNumberOfVariables());
 chordFinder = new G4ChordFinder(intgrDriver);

 G4double deltaChord        = 3.0*mm;
 chordFinder->SetDeltaChord( deltaChord );

 G4double deltaIntersection = 0.1*mm;
 globFieldManager->SetDeltaIntersection(deltaIntersection);

 G4double deltaOneStep = 0.01*mm;
 globFieldManager->SetAccuraciesWithDeltaOneStep(deltaOneStep);
 
 G4double epsMax       = 1.0e-4;
 G4double epsMin       = 2.5e-7;
 globFieldManager->SetMinimumEpsilonStep(epsMin);
 globFieldManager->SetMaximumEpsilonStep(epsMax);
     
 globFieldManager->SetChordFinder(chordFinder);
}

MyGlobField::~MyGlobField()
{
 delete globGravfield;
 globGravfield = nullptr;
}

