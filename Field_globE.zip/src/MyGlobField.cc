#include "MyGlobField.hh"

//#define SU *mm

MyGlobField::MyGlobField()
{
// Total field
 globFieldManager = G4TransportationManager::GetTransportationManager()->GetFieldManager();
 globEfield       = new G4UniformElectricField(G4ThreeVector(0.0,3000.0*kilovolt/cm,0.0));
 globFieldManager->SetDetectorField(globEfield);
 globEquation     = new G4EqMagElectricField(globEfield);
 globStepper      = new G4ClassicalRK4(globEquation,8);
 globntgrDriver   = new G4MagInt_Driver(0.1*mm, globStepper, globStepper->GetNumberOfVariables());
 globChordFinder  = new G4ChordFinder(globntgrDriver);
 globFieldManager->SetChordFinder(globChordFinder);
}

MyGlobField::~MyGlobField()
{
 delete globEfield;       globEfield = nullptr;

 delete globChordFinder;  globChordFinder= nullptr;
 delete globStepper;      globStepper = nullptr;
 delete globEquation;     globEquation = nullptr;
}
