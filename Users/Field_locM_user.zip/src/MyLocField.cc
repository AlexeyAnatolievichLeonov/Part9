#include "MyLocField.hh"

//#define SU *mm

MyLocField::MyLocField()

{
// Local field
// myEMfield      = new G4UniformMagField(G4ThreeVector(2.*tesla,0.,0.));
 myEMfield      = new CylinderField(50.*mm,40.*mm,100.*tesla);
 myFieldManager = new G4FieldManager(myEMfield);
}

MyLocField::~MyLocField()
{
 delete myEMfield;      myEMfield = nullptr;
}

