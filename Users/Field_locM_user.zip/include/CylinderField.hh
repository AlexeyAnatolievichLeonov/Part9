#ifndef CPROJECT_cylinderFIELD_HH
#define CPROJECT_cylinderFIELD_HH

#include "G4SystemOfUnits.hh"
#include "G4MagneticField.hh"
#include "G4UniformMagField.hh"

class CylinderField : public G4MagneticField
{
 public:

  CylinderField(G4double radius, G4double det_length, G4double By);
  ~CylinderField();

  virtual void GetFieldValue(const G4double Point[4], G4double *pField) const;

 private:
  G4double fradius;
  G4double fdet_length;
  G4double fBy;
};
#endif //CPROJECT_cylinderFIELD_HH