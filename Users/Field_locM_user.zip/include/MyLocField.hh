#ifndef CPROJECT_FIELD_HH
#define CPROJECT_FIELD_HH

#include "G4SystemOfUnits.hh"

#include "CylinderField.hh"

#include "G4UniformElectricField.hh"
#include "G4UniformMagField.hh"
#include "G4MagneticField.hh"
#include "G4FieldManager.hh"
#include "G4TransportationManager.hh"
#include "G4EquationOfMotion.hh"
#include "G4EqMagElectricField.hh"
#include "G4Mag_UsualEqRhs.hh"
#include "G4MagIntegratorStepper.hh"
#include "G4MagIntegratorDriver.hh"
#include "G4ChordFinder.hh"

#include "G4ClassicalRK4.hh"

class MyLocField
{
 public:

  G4MagneticField* myEMfield;
  G4FieldManager* myFieldManager;

 MyLocField();
 ~MyLocField();
};
 
#endif //CPROJECT_FIELD_HH