#include "MyLocField.hh"

//#define SU *mm

MyLocField::MyLocField()

{
// Total field
 globFieldManager = G4TransportationManager::GetTransportationManager()->GetFieldManager();
// globMfield       = new G4UniformMagField(G4ThreeVector(2.*tesla,0.,0.));
 globMfield      = new CylinderField(100.*mm,40.*mm,25.*tesla);
 globFieldManager->SetDetectorField(globMfield);
 globFieldManager->CreateChordFinder(globMfield);

}

MyLocField::~MyLocField()
{
 delete globMfield;       globMfield = nullptr;
}

