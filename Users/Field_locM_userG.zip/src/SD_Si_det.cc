#include "SD_Si_det.hh"
#include "SD_Si_det_hit.hh"
#include<G4OpticalPhoton.hh>

SD_Si_det :: SD_Si_det (G4String SDname) : G4VSensitiveDetector(SDname) 
{
 collectionName.insert("SD_Si_det_hitCollection");
 
 G4String filename[10];
 char str[2+sizeof(char)];
 G4int i;
 for (i=0;i<10;i++)
 {
  filename[i] ="hit_Si_det_";
  sprintf(str,"%d",i+1);
  filename[i]+=str;
  filename[i]+=".dat";
//  G4cout<<filename[i]<<" "<<G4endl;
  hit_SD_Si_det[i].open(filename[i],std::fstream::out);
 }
 
 for (i=0; i<10; i++) 
 {SumE[i]=0.;}
}

SD_Si_det :: ~SD_Si_det()
{
 for (G4int i=0; i<10; i++) 
 {hit_SD_Si_det[i].close();}
}

void SD_Si_det :: Initialize(G4HCofThisEvent* HCE)
{
 hitCollection = new SD_Si_det_hitCollection(GetName(), collectionName[0]);
 
 static G4int HCID=-1;
 if (HCID<0) HCID = GetCollectionID(0);
 HCE->AddHitsCollection(HCID,hitCollection);
}

extern G4int eventID;

void SD_Si_det :: EndOfEvent(G4HCofThisEvent*)
{
 for (G4int i=0; i<10; i++) 
 {hit_SD_Si_det[i] << std::setw(10) << SumE[i] << G4endl;}
 for (G4int i=0; i<10; i++) 
 {SumE[i]=0.;}
}

G4bool SD_Si_det :: ProcessHits(G4Step* step, G4TouchableHistory*)
{
 if (step->GetPostStepPoint()->GetMaterial()==G4NistManager::Instance()->FindOrBuildMaterial("G4_Si"))
 {
  G4TouchableHandle touchable = step->GetPreStepPoint()->GetTouchableHandle();
//  G4TouchableHandle touchable1 = step->GetPreStepPoint()->GetTouchableHandle();  
  G4int copyNo   = touchable->GetVolume(0)->GetCopyNo();
//  G4int copyNo1  = touchable1->GetVolume(0)->GetCopyNo();
//  G4String pname = step->GetTrack()->GetDynamicParticle()->GetDefinition()->GetParticleName();
  G4double edep  = 0.;
//  G4double time_ = step->GetPreStepPoint()->GetGlobalTime();
//  edep           = step->GetTrack()->GetDynamicParticle()->GetTotalEnergy()*1e6;
  edep           = step->GetTotalEnergyDeposit();

  this->AddSumE(edep,copyNo);
 }
 SD_Si_det_hit *aHit = new SD_Si_det_hit();
 aHit->SetEdep(step->GetTotalEnergyDeposit());
 aHit->SetLayerNumber(step->GetPreStepPoint()->GetTouchableHandle()->GetVolume(0)->GetCopyNo());
 hitCollection->insert(aHit);
 
 return true; 
}

