#include "CylinderField.hh"

//#define SU *mm

CylinderField::CylinderField(G4double radius, G4double det_length, G4double Bx)
{
 fradius=radius;
 fdet_length=det_length;
 fBx=Bx;
}
CylinderField::~CylinderField()
{
}

void CylinderField::GetFieldValue(const G4double Point[4], G4double *pField) const
{
 if ((abs(Point[0])<fdet_length)&(powf((powf(Point[1],2.)+powf(Point[2],2.)),0.5)<fradius))
 {
  pField[0]=fBx;
 }
 else
 {
  pField[0]=0.;
 }
 pField[1]=0.;
 pField[2]=0.;
 pField[3]=0.;
 pField[4]=0.;
 pField[5]=0.;

}
