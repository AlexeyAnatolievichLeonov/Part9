#include "MyField.hh"

//#define SU *mm

MyField::MyField()
{
// Total field
 globFieldManager = G4TransportationManager::GetTransportationManager()->GetFieldManager();
// globEfield       = new G4UniformElectricField(G4ThreeVector(0.0,0.0,10000.0*kilovolt/cm));
 globEfield       = new CylinderField(powf(10.,8.5)*volt,1.*mm,100.*mm,400.*mm);
 globFieldManager->SetDetectorField(globEfield);
 globEquation     = new G4EqMagElectricField(globEfield);
 globStepper      = new G4ClassicalRK4(globEquation,8);
 globntgrDriver   = new G4MagInt_Driver(0.1*mm, globStepper, globStepper->GetNumberOfVariables());
 globChordFinder  = new G4ChordFinder(globntgrDriver);
 globFieldManager->SetChordFinder(globChordFinder);
}

MyField::~MyField()
{
 delete globEfield;       globEfield = nullptr;
 delete globChordFinder;  globChordFinder= nullptr;
 delete globStepper;      globStepper = nullptr;
 delete globEquation;     globEquation = nullptr;
}
