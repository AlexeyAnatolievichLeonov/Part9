#include <PrimaryPart.hh>

PrimaryPart::PrimaryPart(std::ofstream& ofsa)
{
 char string[1000];
 std::ifstream init;
 G4double E0;
 init.open("./in/input.dat");
 init.getline(string,1000);
 init>>E0;
 init.close();
 GProton = new G4ParticleGun(1);
 GProton->SetParticleDefinition(G4Proton::ProtonDefinition());
 GProton->SetParticleEnergy(E0 * MeV);

 this->f_prim=&ofsa;
 (*f_prim) << std::setw(12) << "Hi from PrimaryPart! " <<E0<< std::endl;
}

PrimaryPart::~PrimaryPart() 
{
 (*f_prim) << std::setw(12) << "Bye from PrimaryPart!" << std::endl;
}

//��������� ���������
void PrimaryPart::GeneratePrimaries(G4Event* anEvent)
{
 G4double x_position=(G4UniformRand()-0.5)*10.*cm;
 G4double y_position=(G4UniformRand()-0.5)*1.*cm;
 GProton->SetParticlePosition(G4ThreeVector(x_position, y_position, -20.*cm));
 GProton->SetParticleMomentumDirection(G4ThreeVector(0, 0, 1));
 GProton->GeneratePrimaryVertex(anEvent); 
}
