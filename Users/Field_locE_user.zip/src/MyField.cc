#include "MyField.hh"

//#define SU *mm

MyField::MyField():myEMfield(0), myEquation(0), myStepper(0), myntgrDriver(0), myChordFinder(0), myFieldManager(0)
{
// Local field
// myEMfield      = new G4UniformElectricField(G4ThreeVector(0.0,100000.*kilovolt/cm,0.0));
 myEMfield      = new CylinderField(powf(10.,9.)*volt,1.*mm,100.*mm,400.*mm);
 myEquation     = new G4EqMagElectricField(myEMfield);
 myStepper      = new G4ClassicalRK4(myEquation,8);
 myntgrDriver   = new G4MagInt_Driver(0.001*mm, myStepper, myStepper->GetNumberOfVariables());
 myChordFinder  = new G4ChordFinder(myntgrDriver);
 myFieldManager = new G4FieldManager(myEMfield,myChordFinder,true);
}

MyField::~MyField()
{
 delete myChordFinder;  myChordFinder= nullptr;
 delete myStepper;      myStepper = nullptr;
 delete myEquation;     myEquation = nullptr;
 delete myEMfield;      myEMfield = nullptr;

}
