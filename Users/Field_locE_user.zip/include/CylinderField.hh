#ifndef CPROJECT_cylinderFIELD_HH
#define CPROJECT_cylinderFIELD_HH

#include "G4SystemOfUnits.hh"
#include "G4ElectricField.hh"
#include "G4UniformElectricField.hh"

class CylinderField : public G4ElectricField 
{
 public:

  CylinderField(G4double voltage, G4double rmin, G4double rmax, G4double det_length);
  ~CylinderField();

  virtual void GetFieldValue(const G4double Point[4], G4double *pField) const;

 private:
  G4double fvoltage;
  G4double frmin;
  G4double frmax;
  G4double fdet_length;

};
 
#endif //CPROJECT_cylinderFIELD_HH